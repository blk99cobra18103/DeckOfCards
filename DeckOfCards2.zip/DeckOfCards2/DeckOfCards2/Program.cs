﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeckOfCards2
{
    class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Deck of Cards Application");
            Console.WriteLine("----------------------------------------");
            Console.WriteLine("\nBelow is a listing of the available commands.");
            Console.WriteLine(" Q = close the application");
            Console.WriteLine(" N = get a new deck");
            Console.WriteLine(" S = shuffle the current deck");
            Console.WriteLine(" D = draw the next card");
            Console.WriteLine(" R = display all of the remaining cards");

            bool quit = false;
            Deck myDeck = new Deck();
            bool createdDeck = false;

            while (!quit)
            {
                Console.WriteLine("\nEnter Command Choice:");
                string command = Console.ReadLine();
                if(command.ToUpper() == "Q")
                {
                    quit = true;
                    Environment.Exit(0);
                }
                else
                {
                    if(command.ToUpper() != "N" && command.ToUpper() != "S" && command.ToUpper() != "D" && command.ToUpper() != "R")
                    {
                        Console.WriteLine("\nUnrecognized Command. Please try again.");
                    } else
                    {
                        switch (command.ToUpper())
                        {
                            case "N":
                                myDeck.CreateDeck();
                                createdDeck = true;
                                /*for (int i = 0; i < 52; i++)
                                {
                                    Console.WriteLine(myDeck.DealCard(i));
                                }*/

                                //Console.WriteLine(myDeck.DealCard());

                                Console.WriteLine("\nA new deck has been created.");
                                break;
                            case "S":
                                if(createdDeck)
                                {
                                    myDeck.SuffleDeck();
                                    Console.WriteLine("\nThe current deck has been shuffled.");

                                }
                                else
                                {
                                    Console.WriteLine("\nYou cannot shuffle without creating a deck first!");
                                }
                                //Console.WriteLine(myDeck.DealCard());

                                break;
                            case "D":
                                if (createdDeck)
                                {
                                    Console.WriteLine(myDeck.DealCard(0));
                                }
                                else
                                {
                                    Console.WriteLine("\nYou cannot deal the next card without creating a deck first!");
                                }
                                break;
                            case "R":
                                if (createdDeck)
                                {
                                    for (int i = 1; i < 52; i++)
                                    {
                                        Console.WriteLine(myDeck.DealCard(i));
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("\nYou cannot display the remainder of the deck without creating a deck first!");
                                }
                                break;
                        }
                    }
                }
            }
        }

    }
}
