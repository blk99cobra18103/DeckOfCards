﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeckOfCards2
{
    class Deck
    {
        private Card[] deckofcards;
        private int Current_Card;
        private const int NUMOFCARDS = 52;
        private Random randomNumber;

        public Deck()
        {
            deckofcards = new Card[NUMOFCARDS];
            Current_Card = 0;
            randomNumber = new Random();
        }

        public void CreateDeck()
        {
            string[] FACES = { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" };
            string[] SUITS = { "h", "d", "c", "s" };

            for (int counter = 0; counter < deckofcards.Length; counter++)
            {
                deckofcards[counter] = new Card(FACES[counter % 13], SUITS[counter / 13]);
            }

        }

        public void SuffleDeck()
        {
            Current_Card = 0;
            int cardtoshuffle1;
            int cardtoshuffle2;

            for (int x = 0; x < deckofcards.Length; x++)
            {
                cardtoshuffle1 = randomNumber.Next(NUMOFCARDS);
                cardtoshuffle2 = randomNumber.Next(NUMOFCARDS);
                Card temp = deckofcards[cardtoshuffle1];
                deckofcards[cardtoshuffle1] = deckofcards[cardtoshuffle2];
                deckofcards[cardtoshuffle2] = temp;
            }
        }

        public Card DealCard(int cardposition)
        {
            if (Current_Card < deckofcards.Length)
            {
                return deckofcards[cardposition];
            }
            else
            {
                return null;
            }
        }

    }
}
